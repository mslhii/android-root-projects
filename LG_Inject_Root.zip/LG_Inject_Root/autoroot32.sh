#!/bin/bash

chmod 0644 system.img
mount -o loop,rw -t ext4 system.img operatingtable/


mkdir operatingtable/app/SuperSU
chmod 0755 operatingtable/app/SuperSU
cp su32/Superuser.apk operatingtable/app/SuperSU/SuperSU.apk
chmod 0644 operatingtable/app/SuperSU/SuperSU.apk
chcon --reference=operatingtable/bin/reboot operatingtable/app/SuperSU/SuperSU.apk


if [ ! -e operatingtable/etc/install-recovery_original.sh ]; then
 if [ -e operatingtable/etc/install-recovery.sh ]; then
  mv operatingtable/etc/install-recovery.sh operatingtable/etc/install-recovery_original.sh
 fi
fi


if [ ! -e operatingtable/bin/install-recovery_original.sh ]; then
 if [ -e operatingtable/bin/install-recovery.sh ]; then
  mv operatingtable/bin/install-recovery.sh operatingtable/bin/install-recovery_original.sh
 fi
fi
cp su32/install-recovery.sh operatingtable/etc/install-recovery.sh
chmod 0755 operatingtable/etc/install-recovery.sh
chcon --reference=operatingtable/bin/toolbox operatingtable/etc/install-recovery.sh
ln -s /system/etc/install-recovery.sh operatingtable/bin/install-recovery.sh


cp su32/su operatingtable/xbin/su
chmod 0755 operatingtable/xbin/su
chcon --reference=operatingtable/bin/reboot operatingtable/xbin/su


mkdir operatingtable/bin/.ext
chmod 0755 operatingtable/bin/.ext
cp su32/su operatingtable/bin/.ext/.su
chmod 0755 operatingtable/bin/.ext/.su
chcon --reference=operatingtable/bin/reboot operatingtable/bin/.ext/.su


cp su32/su operatingtable/xbin/daemonsu
chmod 0755 operatingtable/xbin/daemonsu
chcon --reference=operatingtable/bin/reboot operatingtable/xbin/daemonsu


cp su32/su operatingtable/xbin/sugote
chmod 0755 operatingtable/xbin/sugote
chcon --reference=operatingtable/bin/app_process32 operatingtable/xbin/sugote


cp su32/supolicy operatingtable/xbin/supolicy
chmod 0755 operatingtable/xbin/supolicy
chcon --reference=operatingtable/bin/reboot operatingtable/xbin/supolicy


cp su32/libsupol.so operatingtable/lib/libsupol.so
chmod 0644 operatingtable/lib/libsupol.so
chcon --reference=operatingtable/bin/reboot operatingtable/lib/libsupol.so


if [ ! -e operatingtable/bin/app_process32_original ]; then
 if [ -e operatingtable/bin/app_process32 ]; then
  cp operatingtable/bin/app_process32 operatingtable/bin/app_process32_original
 fi
fi
chmod 0755 operatingtable/bin/app_process32_original
chcon --reference=operatingtable/bin/app_process32 operatingtable/bin/app_process32_original
rm operatingtable/bin/app_process32

if [ -e operatingtable/bin/app_process32_original ]; then
  cp operatingtable/bin/app_process32_original operatingtable/bin/app_process_init
fi
chmod 0755 operatingtable/bin/app_process_init
chcon --reference=operatingtable/bin/reboot operatingtable/bin/app_process_init

rm operatingtable/bin/app_process
ln -s /system/xbin/daemonsu operatingtable/bin/app_process

ln -s /system/xbin/daemonsu operatingtable/bin/app_process32


if [ -e operatingtable/etc/init.d ]; then
  cp su/99SuperSUDaemon operatingtable/etc/init.d/99SuperSUDaemon
  chmod 0755 operatingtable/etc/init.d/99SuperSUDaemon
  chcon --reference=operatingtable/bin/reboot operatingtable/etc/init.d/99SuperSUDaemon
fi

umount operatingtable
mv system.img rootedsystem.img
