A simple script to inject root into system.img files

Instructions:
1:	Place unrooted "system.img" into the Inject_Root folder
2:	run autoroot.sh

system.img should now be rooted

Notes:

This requires Linux with root access